"""Download Starbucks Coffee Korea filings and standardized financial statements from Open DART.
Set DART_API_KEY in the environment. Output is deliberately versioned in data/processed.
"""
import io, os, sys, zipfile, json
from pathlib import Path
import requests
import pandas as pd

BASE = "https://opendart.fss.or.kr/api"
ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"; OUT = ROOT / "data" / "processed"
RAW.mkdir(parents=True, exist_ok=True); OUT.mkdir(parents=True, exist_ok=True)
KEY = os.environ.get("DART_API_KEY")
TARGET = "스타벅스커피코리아"

def get(path, **params):
    if not KEY: raise RuntimeError("DART_API_KEY 환경변수가 필요합니다.")
    r = requests.get(f"{BASE}/{path}", params={"crtfc_key":KEY, **params}, timeout=60)
    r.raise_for_status(); return r

def corp_code():
    cache = RAW / "corp_codes.csv"
    if cache.exists(): df=pd.read_csv(cache, dtype=str)
    else:
        r=get("corpCode.xml")
        with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            xml=z.read(z.namelist()[0])
        df=pd.read_xml(io.BytesIO(xml), xpath="//list", dtype=str)
        df.to_csv(cache,index=False,encoding="utf-8-sig")
    hit=df[df["corp_name"].str.replace("㈜|\\s", "", regex=True).str.contains("스타벅스커피코리아", na=False)]
    if hit.empty: raise LookupError(f"{TARGET} 법인코드를 찾지 못했습니다. DART 검색명을 확인하세요.")
    return hit.iloc[0]["corp_code"]

def latest_audit(corp, year):
    # F=감사보고서. 접수번호를 확보해 원문 XML도 보관한다.
    data=get("list.json", corp_code=corp, bgn_de=f"{year}0101", end_de=f"{year+1}1231", pblntf_ty="F", page_count=100).json()
    rows=data.get("list", [])
    if not rows: return None
    rows=[x for x in rows if "감사보고서" in x.get("report_nm", "")]
    return sorted(rows, key=lambda x:x["rcept_no"], reverse=True)[0] if rows else None

def download_document(rcept_no):
    r=get("document.xml", rcept_no=rcept_no)
    p=RAW/f"{rcept_no}.zip"; p.write_bytes(r.content)
    return p

def financials(corp, year):
    # 11011=사업보고서. 비상장 법인은 표준 API 데이터가 없을 수 있어 원문도 함께 저장한다.
    js=get("fnlttSinglAcnt.json", corp_code=corp, bsns_year=str(year), reprt_code="11011", fs_div="OFS").json()
    if js.get("status") != "000": return pd.DataFrame(), js
    return pd.DataFrame(js.get("list", [])), js

def main():
    years=[int(x) for x in sys.argv[1:]] or [2022,2023,2024]
    corp=corp_code(); meta={"target":TARGET,"corp_code":corp,"years":years,"source":"Open DART API"}
    all_rows=[]; filings=[]
    for y in years:
        filing=latest_audit(corp,y)
        if filing:
            download_document(filing["rcept_no"]); filings.append({"year":y,**filing})
        df,status=financials(corp,y)
        if not df.empty:
            df["bsns_year"]=str(y); all_rows.append(df)
        else:
            print(f"{y}: 표준 재무 API 미제공 ({status.get('message')}); 감사보고서 원문 ZIP을 저장했습니다.")
    pd.DataFrame(filings).to_csv(OUT/"filings.csv",index=False,encoding="utf-8-sig")
    if all_rows: pd.concat(all_rows,ignore_index=True).to_csv(OUT/"dart_financials_raw.csv",index=False,encoding="utf-8-sig")
    (OUT/"run_metadata.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding="utf-8")
    print(json.dumps(meta,ensure_ascii=False))
if __name__ == "__main__": main()
