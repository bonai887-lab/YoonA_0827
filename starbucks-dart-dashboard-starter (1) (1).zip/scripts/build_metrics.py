"""Normalize DART account names and calculate annual ratios. Run after fetch_dart.py."""
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]; IN=ROOT/'data/processed/dart_financials_raw.csv'; OUT=ROOT/'data/processed/metrics.csv'
# Standard names vary by filing; add variants here only after validating against source report.
MAP={'매출액':'revenue','영업수익':'revenue','영업이익':'operating_income','당기순이익':'net_income','당기순이익(손실)':'net_income','자산총계':'total_assets','부채총계':'total_liabilities','자본총계':'total_equity','유동자산':'current_assets','유동부채':'current_liabilities','현금및현금성자산':'cash','영업활동현금흐름':'cfo','영업활동으로 인한 현금흐름':'cfo'}
def n(x):
    try:return float(str(x).replace(',','').replace('(','-').replace(')',''))
    except:return None
df=pd.read_csv(IN,dtype=str); df['account_nm']=df['account_nm'].str.strip(); df=df[df.account_nm.isin(MAP)].copy(); df['metric']=df.account_nm.map(MAP); df['value']=df['thstrm_amount'].map(n)
p=df.pivot_table(index='bsns_year',columns='metric',values='value',aggfunc='first').sort_index()
p['revenue_growth_pct']=p['revenue'].pct_change()*100
p['operating_margin_pct']=p['operating_income']/p['revenue']*100
p['net_margin_pct']=p['net_income']/p['revenue']*100
p['current_ratio_pct']=p['current_assets']/p['current_liabilities']*100
p['debt_ratio_pct']=p['total_liabilities']/p['total_equity']*100
p['equity_ratio_pct']=p['total_equity']/p['total_assets']*100
p['cfo_to_net_income']=p['cfo']/p['net_income']
p['roa_pct']=p['net_income']/p['total_assets'].rolling(2).mean()*100
p['roe_pct']=p['net_income']/p['total_equity'].rolling(2).mean()*100
p.reset_index().to_csv(OUT,index=False,encoding='utf-8-sig')
print(f'created {OUT}')
