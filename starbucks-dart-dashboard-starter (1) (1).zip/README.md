# Starbucks Coffee Korea — DART Financial Dashboard

Open DART API 기반 재무 데이터 수집 및 GitHub Pages 정적 대시보드 프로젝트입니다.

## 사전 준비
1. [Open DART](https://opendart.fss.or.kr/)에서 API 인증키를 발급합니다.
2. 로컬에서는 `export DART_API_KEY='발급키'`를 설정합니다. 키를 코드나 Git에 기록하지 않습니다.
3. `pip install -r requirements.txt`

## 실행
```bash
python scripts/fetch_dart.py 2022 2023 2024
python scripts/build_metrics.py
```

`data/processed/filings.csv`에는 감사보고서 접수번호, `data/raw/`에는 DART 원문 ZIP, `metrics.csv`에는 계산된 지표가 생성됩니다.

## 해석 원칙
- 금액/비율과 3개년 추세를 함께 확인합니다.
- ROA·ROE는 평균 자산·평균 자본을 사용합니다.
- 비상장사 감사보고서는 표준 재무 API가 비어 있을 수 있습니다. 이 경우 원문 감사보고서의 계정명과 단위를 검증한 뒤 `MAP`을 보완합니다.
- CAPEX, 이자비용, 매출채권·재고·매입채무가 확보되면 FCF, 이자보상배율, CCC를 추가합니다.

## GitHub Pages
`index.html`을 저장소 루트에 두고 GitHub Pages의 배포 원본을 `main / root`로 설정합니다. 자동 수집은 GitHub Actions에서 `DART_API_KEY`를 Repository Secret으로 등록한 뒤 실행하세요.
